package hi.throunhugbunadar.backend;

import java.util.Date;

/**
 * Bókun á herbergi.
 */

public class Reservation {
    private User user;
    private HotelRooms hotelType;
    private Date arrival;
    private Date departure;
}
