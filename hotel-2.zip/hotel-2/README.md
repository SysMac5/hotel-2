# Hótel 2

Verkefni í Þróun hugbúnaðar.

Hugbúnaður þar sem hægt er að bóka hótelherbergi.
